package org.geotools.tutorial.quickstart;

import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.geotools.data.DataStore;
import org.geotools.data.DataStoreFinder;
import org.geotools.data.geojson.GeoJSONDataStoreFactory;
import org.geotools.data.simple.SimpleFeatureCollection;
import org.geotools.data.simple.SimpleFeatureIterator;
import org.geotools.data.simple.SimpleFeatureSource;
import org.geotools.filter.text.cql2.CQL;
import org.geotools.util.URLs;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.filter.Filter;

/* This script receives two inputs a geojson polygon file of AORs and and sample json containing latitude and longitude values.
It then iterates through the json and runs an point contained polygon query. This query examines if the latitude/longitude 
point is contained within the value and if it is pushes the name of the AOR it is within to the json object. A new json file 
is then written.   */


public class AOR_Geoquery_Geojson {

    public static void main(String[] args) throws Exception {
       //Get Geojson input
       //Got from https://stackoverflow.com/questions/53957417/parse-geojson-file-with-java-topology-suite-or-geotools
       File inFile = new File("/Users/mayronajarro/nb-projects/AOR/GLB_AORs.geojson");
       //create map and input url parameters then use to create geotools datastore 
       Map<String, Object> params = new HashMap<>();
        params.put(GeoJSONDataStoreFactory.URLP.key, URLs.fileToUrl(inFile));
        DataStore newDataStore = DataStoreFinder.getDataStore(params);
        //create featuresouce variable from datastore and point to type
        SimpleFeatureSource featureSource = newDataStore.getFeatureSource(newDataStore.getTypeNames()[0]);
  
        
        //Get json coordinates File
        Object obj = new JSONParser().parse(new FileReader("/Users/mayronajarro/nb-projects/AOR/latlongs.json"));
        // typecasting obj to JSONObject 
        JSONObject jo = (JSONObject) obj; 
        
        JSONArray locationArray = (JSONArray) jo.get("TestJson");
        Iterator locitr = locationArray.iterator();
        
        //Creating new empty json object and array for output json
        JSONObject newjson = new JSONObject();
        JSONArray newarray = new JSONArray();
       
        //iterate through objects in json array 
        while (locitr.hasNext())
        {
                JSONObject innerObject = (JSONObject) locitr.next();
                
                String lat = innerObject.get("Latitude").toString();
                String longi = innerObject.get("Longitude").toString();

                //Query uses Filter and uses geometry information from polygon geojson and lat long strings from json
                //Got from https://stackoverflow.com/questions/21700957/extract-polygons-from-shapefile-using-geotools
                Filter pointInPolygon = CQL.toFilter("CONTAINS(geometry, POINT("+longi+" "+lat+"))");
                
                SimpleFeatureCollection features = featureSource.getFeatures(pointInPolygon);
                if(!features.isEmpty()){
                    SimpleFeatureIterator iterator = features.features();
                    try {
                        while (iterator.hasNext()) {
                            SimpleFeature feature = iterator.next();
                            String AOR = feature.getAttribute("AORs").toString();
                            System.out.println(lat+", "+longi+" point is contained within "+ AOR +" AOR polygon");
                            innerObject.put("AOR", AOR);
                            //inputs AOR value into json object                           
                        }
                    } finally {
                        iterator.close(); // Important to close
                    }
                //Add to new json array
                newarray.add(innerObject);
                }
                else{
                    System.out.println("THe query did not work. Check your input variables. ");
                }
                    
        }
        //Add json array to new json object.
        newjson.put("NewJSON",newarray);
        System.out.println(newjson);
        if(!newjson.isEmpty()){
            //writingJSON
            PrintWriter pw = new PrintWriter("/Users/mayronajarro/AORjava/queryoutput.json"); 
            pw.write(newjson.toJSONString()); 
            
            pw.flush(); 
            pw.close(); 
        }
        else{ System.out.println("Query did not work. Check you input files");}

        
    }
}