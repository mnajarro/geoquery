package org.geotools.tutorial.quickstart;

import java.io.File;
import java.io.FileReader;
import java.util.Iterator;
import org.geotools.data.FileDataStore;
import org.geotools.data.FileDataStoreFinder;
import org.geotools.data.simple.SimpleFeatureCollection;
import org.geotools.data.simple.SimpleFeatureIterator;
import org.geotools.data.simple.SimpleFeatureSource;
import org.geotools.filter.text.cql2.CQL;
import org.geotools.swing.data.JFileDataStoreChooser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.filter.Filter;



public class AOR_Geoquery_shp_input {


    public static void main(String[] args) throws Exception {
   
        //In case we need to select the shapefile. Leaving in for now.
        // display a data store file chooser dialog for shapefiles
         File file = JFileDataStoreChooser.showOpenFile("shp", null);
         if (file == null) {
             return;
         }
 
         FileDataStore store = FileDataStoreFinder.getDataStore(file);
         SimpleFeatureSource featureSource = store.getFeatureSource();
        
        //json
        Object obj = new JSONParser().parse(new FileReader("/Users/mayronajarro/nb-projects/AOR/latlongs.json"));
        // typecasting obj to JSONObject 
        JSONObject jo = (JSONObject) obj; 
 
        JSONArray locationArray = (JSONArray) jo.get("TestJson");
        Iterator locitr = locationArray.iterator();
        JSONObject newjson = new JSONObject();
        JSONArray newarray = new JSONArray();
       
        
        while (locitr.hasNext())
        {
                JSONObject innerObject = (JSONObject) locitr.next();
                
                String lat = innerObject.get("Latitude").toString();
                String longi = innerObject.get("Longitude").toString();
                
                //Got from https://stackoverflow.com/questions/21700957/extract-polygons-from-shapefile-using-geotools

                Filter pointInPolygon = CQL.toFilter("CONTAINS(the_geom, POINT("+longi+" "+lat+"))");
                SimpleFeatureCollection features = featureSource.getFeatures(pointInPolygon);

                    SimpleFeatureIterator iterator = features.features();
                    try {
                        while (iterator.hasNext()) {
                            SimpleFeature feature = iterator.next();
                            String AOR = feature.getAttribute("AORs").toString();
                            System.out.println(lat+", "+longi+" point is contained within "+ AOR +" AOR polygon");
                            innerObject.put("AOR", AOR);
                            
                        }
                    } finally {
                        iterator.close(); // Important to close
                    }
     
                newarray.add(innerObject);
                
        }
        newjson.put("NewJSON",newarray);
        System.out.println(newjson);

        //writingJSON
        /*PrintWriter pw = new PrintWriter("JSONExample.json"); 
        pw.write(jo.toJSONString()); 
          
        pw.flush(); 
        pw.close(); */

        
    }
}